#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define ROZ 300
#define MAX 50

size_t getline(char** lineptr, size_t* n, FILE* stream)
{
    char* bufptr = NULL;
    char* p = bufptr;
    size_t size;
    int c;

    if (lineptr == NULL)
    {
        return -1;
    }
    if (stream == NULL)
    {
        return -1;
    }
    if (n == NULL)
    {
        return -1;
    }
    bufptr = *lineptr;
    size = *n;
    c = fgetc(stream);
    if (c == EOF)
    {
        return -1;
    }
    if (bufptr == NULL)
    {
        bufptr = malloc(128);
        if (bufptr == NULL)
        {
            return -1;
        }
        size = 128;
    }
    p = bufptr;
    while (c != EOF)
    {
        if ((p - bufptr) > (size - 1))
        {
            size = size + 128;
            bufptr = realloc(bufptr, size);
            if (bufptr == NULL)
            {
                return -1;
            }
        }
        *p++ = c;
        if (c == '\n')
        {
            break;
        }
        c = fgetc(stream);
    }

    *p++ = '\0';
    *lineptr = bufptr;
    *n = size;

    return p - bufptr - 1;
}
//--------------STRUKTURA------------------
struct Pytanie//nowy
{
    struct Pytanie *poprzedni;
    struct Pytanie *nastepny;
    char tresc[ROZ];
    char odpowiedzi[ROZ];
    char poprawna;
};
//--------------STRUKTURA------------------
struct Pytanie* ostatni_element(struct Pytanie *head)
{
    struct Pytanie *ostatni = head;
    while(ostatni->nastepny != NULL)
    {
        ostatni = ostatni->nastepny;
    }
    return ostatni;
}

void poczatek_listy(struct Pytanie *head)
{
    head->poprzedni = NULL;
    head->nastepny = NULL;
    head->tresc[0] = ' ';
    head->odpowiedzi[0] = ' ';
    head->poprawna = 0;
}
void dodajNaKoniecListy(struct Pytanie *head, char tresc[], char odpowiedzi[], char poprawna)
{
    struct Pytanie *ostatni = ostatni_element(head);
    struct Pytanie *nowePytanie = malloc(sizeof(struct Pytanie));
//uzupelnianie pytania
    nowePytanie->poprzedni = ostatni;
    nowePytanie->nastepny = NULL;
    strcpy(nowePytanie->tresc, tresc); //zapisywanie aktualnego pytania
    strcpy(nowePytanie->odpowiedzi, odpowiedzi);
    nowePytanie->poprawna = poprawna;
    ostatni->nastepny = nowePytanie;
}
void wczytajPytania(struct Pytanie *head, char nazwaPliku[], char tresc[], char odpowiedzi[], char poprawna)
{
    char *linia = NULL;
    size_t dlugosc = 0;
    FILE *plik;
    if ((plik = fopen(nazwaPliku,"r")) == NULL)
    {
        printf("\nNie mozna otworzyc pliku!\n");
        exit(1);
    }
    while(getline(&linia, &dlugosc, plik) != -1)
    {  //Petla zczytuje tresc pytania
        odpowiedzi[0] = '\0';
        strcpy(tresc,linia);

        while(getline(&linia, &dlugosc, plik) != -1)
        {
            if(linia[2] == '\0')
            { //odpowiedz poprawna
                poprawna = linia[0];
                break;
            }
            else
            {   //mozliwe odpowiedzi
                strncat(odpowiedzi,linia,dlugosc);
            }
        }

        dodajNaKoniecListy(head, tresc, odpowiedzi, poprawna);
    }
    fclose(plik);
}
void tryb_klasyczny(struct Pytanie *head, struct Pytanie **nowy, char poprawna, int *aktualnyGracz, int *zdobytePunkty, int liczbaGraczy, int *tura)
{

    if(*nowy == NULL) *nowy = head->nastepny;

    printf("\n~Odpowiada gracz nr %d~\n", *aktualnyGracz+1);
    printf("\n MASZ 20S NA ODPOWIEDZ!!!\n\n");
    printf("%s", (*nowy)->tresc);
    printf("%s", (*nowy)->odpowiedzi);
    //---------ograniczenie czasowe--------------
    int czas=1;
    clock_t start = clock();
    while(czas){

    if(clock()-start>20000) { czas=0; break; }
    if(kbhit())
    {
        scanf(" %c", &poprawna);
        break;
    }
}
    //---------ograniczenie czasowe--------------
    if(poprawna == (*nowy)->poprawna)
    {
        zdobytePunkty[*aktualnyGracz] += 1;
        printf("POPRAWNA ODPOWIEDZ \n");
    }
    else
    {
        if(czas == 0){  printf("Koniec czasu!!!\n"); }
        else         {  printf("ZLA ODPOWIEDZ\n");   }
        printf("poprawna odpowiedz to: %c \n \n",(*nowy)->poprawna);
    }
    (*aktualnyGracz)++;
    if(*aktualnyGracz == liczbaGraczy)
        *aktualnyGracz = 0;
    if((*nowy)->nastepny != NULL)
        *nowy = (*nowy)->nastepny;
    else *nowy = head->nastepny;
}
//-----------------------------------------------GLOWNA----------------------------------------------------------
int main()
{
//----------------zmienne--------------------
    char sciezka[ROZ]={"Pytania/"},tresc[ROZ],odpowiedzi[ROZ],poprawna = -1;
    int liczbaGraczy=1, aktualnyGracz = 0, liczbaTur=1;
    int *zdobytePunkty,wygrany=0,pktwygranego=0,remis=0;
    int poziomTrudnosci = 0, nazwaKategorii = 0,menu;
    char nazwatrudnosc[MAX]="brak",wybranakategoria[MAX]="brak";
//----------------listy--------------------
    struct Pytanie *head = malloc(sizeof(struct Pytanie));
    poczatek_listy(head);
    struct Pytanie *nowy = NULL;
//----------------MENU--------------------
    while(1){

         printf("              QQQQQQQQ      UUUUUU    UUUUUU     IIIII     ZZZZZZZZZZZZZZZZZZZZZ  !!!  \n");
         printf("            QQQQQQQQQQQQ     UUUU      U UU     II   II    ZZZZZ           ZZZZ   !!!  \n");
         printf("           QQQQQ    QQQQQ    UUUU      U UU     II II I    ZZZ            ZZZZ    !!!  \n");
         printf("           QQQQ      QQQQ    UUUU      U UU     II  II     Z            ZZZZ      !!!  \n");
         printf("           QQQQ      QQQQ    UUUU      U UU      III II               ZZZZ        !!!  \n");
         printf("           QQQQ      QQQQ    UUUU      U UU                         ZZZZ          !!!  \n");
         printf("           QQQQ      QQQQ    UUUU      U UU     IIIIIII           ZZZZ            !!!  \n");
         printf("           QQQQ  QQQ QQQQ    UUUU      U UU      I   I          ZZZZ              !!!  \n");
         printf("           QQQQ   QQQ QQQ    UUUU      U UU      I   I        ZZZZ             Z  !!!  \n");
         printf("           QQQQQ   QQQ QQ     UUUU    U UU       I   I       ZZZZ            ZZZ       \n");
         printf("             QQQQQQ QQQ        UUUUUUU UU       I     I     ZZZZ           ZZZZZ  !!!  \n");
         printf("                QQQQ  QQQ        UUUUUU       IIIIIIIIIII  ZZZZZZZZZZZZZZZZZZZZZ  !!!  \n");

         printf("\n Witaj w naszym super uper duper QUIZIE!!! (fanfary)\n");
         printf("Autorzy:\n  Sebastian Pindral - Deweloper\n  Sylwia Osiadlo    - starszy programista\n  Wiktor Paluch     - mlodszy programista\n");
         printf("MENU:\n");
         printf(" 1-Nowa gra\n");
         printf(" 2-wybor ilosci graczy     (Ustawiono=%d)\n",liczbaGraczy);
         printf(" 3-wybor ilosci Tur        (Ustawiono=%d)\n",liczbaTur);
         printf(" 4-wybor poziomu trudnosci (Ustawiono= %s )\n",nazwatrudnosc);
         printf(" 5-wybor kategori          (Ustawiono= %s )\n",wybranakategoria);
         printf(" 6-Wyjscie\n");
         scanf("%d",&menu);

        switch(menu)
        {
        case 1:
//--------------------------------TABLICA PUNKTOW---------------------------------------
                zdobytePunkty = (int*)malloc(liczbaGraczy * sizeof(int));
                for(int i = 0; i < liczbaGraczy; i++)
                    zdobytePunkty[i] = 0;

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX-------CZESC_GLUWNA-------XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    wczytajPytania(head, sciezka, tresc, odpowiedzi, poprawna);
    for(int tura = 1; tura <= liczbaTur; tura++)
    {
        printf("\n\n\t--------------------Runda %d--------------------\n",tura);
        for(int j = 0; j < liczbaGraczy; j++)
        {
            tryb_klasyczny(head, &nowy, poprawna, &aktualnyGracz, zdobytePunkty, liczbaGraczy, &tura);
        }
         if(tura == liczbaTur)
         {
            puts("\n\nKoniec Gry!\n");
            puts("Tabela wynikow:\n");
         }
        for(int j = 0; j < liczbaGraczy; j++)
        {
            printf("Gracz nr %d uzyskal: %d pkt\n", j+1, zdobytePunkty[j]);
            if(pktwygranego<zdobytePunkty[j])
                {
                    wygrany=j+1;
                    pktwygranego=zdobytePunkty[j];
                }
        }
        printf("\n");
    }
    if(liczbaGraczy>1)
    {
    int i=liczbaGraczy;
    while(i)
    {
        if(zdobytePunkty[i]==wygrany) remis++;
        i--;
    }
    if(remis != 0) printf("Remis!!!\n\n");
    else   { printf("Wygral gracz nr %d !!! \n\n",wygrany);}
    }

   system("pause");
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        break;
        case 2:
            printf("Podaj liczbe graczy: "); // LICZBA GRACZY
            scanf("%d", &liczbaGraczy);
        break;
        case 3:
            printf("Podaj liczbe rund: "); // LICZBA RUND
            scanf("%d", &liczbaTur);
        break;
        case 4:
                printf("\nWybierz poziom trudnosci:\n 1-LATWY 2-sredni 3-TRUDNY\n");
                scanf("%d",&poziomTrudnosci);
                switch(poziomTrudnosci)
                {
                    case 1:
                        strncat(sciezka, "latwy/", 6);
                        strcpy(nazwatrudnosc, "latwy");
                    break;
                     case 2:
                        strncat(sciezka, "sredni/", 7);
                        strcpy(nazwatrudnosc, "sredni");
                    break;
                    case 3:
                        strncat(sciezka, "trudny/", 7);
                        strcpy(nazwatrudnosc, "trudny");
                    break;
                    default: printf("nie ma takiej opcji");
                }
        break;
        case 5:
                printf("\nWybierz kategorie:\n 1-BIOLOGIA\n 2-MATEMATYKA\n 3-ZWIERZETA\n 4-INFORMATYKA\n 5-HISTORIA");
                printf("\n 6-JEZYK POLSKI\n 7-KULTURA-SZTUKA\n 8-NAUKA-TECHNIKA\n 9-FILMY-KSIAZKI\n 10-GEOGRAFIA\n");
                scanf("%d",&nazwaKategorii);

                switch(nazwaKategorii){
                case 1:
                    strncat(sciezka, "biologia.txt", 12);
                    strcpy(wybranakategoria, "biologia");
                break;
                case 2:
                    strncat(sciezka,"matematyka.txt",14);
                    strcpy(wybranakategoria, "biologia");
                break;
                case 3:
                    strncat(sciezka,"zwierzeta.txt",13);
                    strcpy(wybranakategoria, "matematyka");
                break;
                case 4:
                    strncat(sciezka,"informatyka.txt",15);
                    strcpy(wybranakategoria, "informatyka");
                break;
                case 5:
                    strncat(sciezka,"historia.txt",12);
                    strcpy(wybranakategoria, "historia");
                break;
                case 6:
                    strncat(sciezka,"polski.txt",10);
                    strcpy(wybranakategoria, "polski");
                break;
                case 7:
                    strncat(sciezka,"kultura.txt",11);
                    strcpy(wybranakategoria, "kultura");
                break;
                case 8:
                    strncat(sciezka,"nauka.txt",9);
                    strcpy(wybranakategoria, "nauka");
                break;
                case 9:
                    strncat(sciezka,"filmy.txt",9);
                    strcpy(wybranakategoria, "filmy");
                break;
                case 10:
                    strncat(sciezka,"geografia.txt",13);
                    strcpy(wybranakategoria, "geografia");
                break;
                default: printf("nie ma takiej opcji");
                }
        break;
        case 6:
            exit(0);
        break;
        default: printf("nie ma takiej opcji");
        }
        system("cls");
    }


    return 0;
}
//Wersja gry 0.9.5.3
