void tryb_klasyczny(struct Pytanie *head, struct Pytanie **nowy, char poprawna, int *aktualnyGracz, int *zdobytePunkty, int liczbaGraczy, int *tura, int czas_gry)
{
    if(*nowy == NULL){ *nowy = head->nastepny; }
    printf("\n\t---------------Odpowiada gracz nr %d------------\n",*aktualnyGracz+1);
    printf("\n\t-------------MASZ %ds NA ODPOWIEDZ!!!----------\n\n",czas_gry);
    printf("%d.%s",*tura, (*nowy)->tresc);
    printf("%s", (*nowy)->odpowiedzi);
    //---------ograniczenie czasowe--------------
    srand(time(0));
    int czas=1;
    clock_t start = clock();
    while(czas){

    if(clock()-start>czas_gry*1000) { czas=0; break; }
    if(kbhit())
    {
        scanf(" %c", &poprawna);
        break;
    }
}
    //---------ograniczenie czasowe--------------
    if(poprawna == (*nowy)->poprawna)
    {
        zdobytePunkty[*aktualnyGracz] += 1;
        printf("POPRAWNA ODPOWIEDZ \n");
    }
    else
    {
        if(czas == 0){  printf("Koniec czasu!!!\n"); }
        else         {  printf("ZLA ODPOWIEDZ\n");   }
        printf("poprawna odpowiedz to: %c \n \n",(*nowy)->poprawna);
    }
}

void tryb_ruletka(struct Pytanie *head, struct Pytanie **nowy, char poprawna, int *aktualnyGracz, int *zdobytePunkty, int liczbaGraczy, int *tura, int czas_gry)
{
    int ruletka=0;
    if(*nowy == NULL){ *nowy = head->nastepny; }
    printf("\n\t---------------Odpowiada gracz nr %d------------\n",*aktualnyGracz+1);
    printf("\n\t-------------MASZ %ds NA ODPOWIEDZ!!!----------\n\n",czas_gry);
    printf("\n 1-Chcesz poznac pytanie?-1pkt czy 2-ryzykujesz?-3pkt \n\n");
    scanf("%d",&ruletka);
    if(ruletka==1){ printf("%s", (*nowy)->tresc); }
    printf("%s", (*nowy)->odpowiedzi);
    //---------ograniczenie czasowe--------------
    srand(time(0));
    int czas=1;
    clock_t start = clock();
    while(czas){

    if(clock()-start>czas_gry*1000) { czas=0; break; }
    if(kbhit())
    {
        scanf(" %c", &poprawna);
        break;
    }
}
    //---------ograniczenie czasowe--------------
    if(poprawna == (*nowy)->poprawna)
    {
        if(ruletka==2)
        {
            zdobytePunkty[*aktualnyGracz] += 3;
        }else{
        zdobytePunkty[*aktualnyGracz] += 1;
        }
        printf("POPRAWNA ODPOWIEDZ \n");
    }
    else
    {
        if(czas == 0){  printf("Koniec czasu!!!\n"); }
        else         {  printf("ZLA ODPOWIEDZ\n");   }
        printf("poprawna odpowiedz to: %c \n \n",(*nowy)->poprawna);
    }
}

void tryb_survival(struct Pytanie *head, struct Pytanie **nowy, char poprawna, int *aktualnyGracz, int *zdobytePunkty, int liczbaGraczy, int *tura, int czas_gry,int zycia,int tabzycia[])
{
    if(*nowy == NULL){ *nowy = head->nastepny; }
    printf("\n\t---------------Odpowiada gracz nr %d------------\n",*aktualnyGracz+1);
    printf("\n\t-------------MASZ %ds NA ODPOWIEDZ!!!----------\n",czas_gry);
    printf("\n\t---------------MASZ %d Zycia!!!----------------\n\n",tabzycia[*aktualnyGracz]);
    printf("%d.%s",*tura, (*nowy)->tresc);
    printf("%s", (*nowy)->odpowiedzi);
    //---------ograniczenie czasowe--------------
    srand(time(0));
    int czas=1;
    clock_t start = clock();
    while(czas){

    if(clock()-start>czas_gry*1000) { czas=0; break; }
    if(kbhit())
    {
        scanf(" %c", &poprawna);
        break;
    }
}
    //---------ograniczenie czasowe--------------
    if(poprawna == (*nowy)->poprawna)
    {
        zdobytePunkty[*aktualnyGracz] += 1;
        printf("POPRAWNA ODPOWIEDZ \n");
    }
    else
    {
        if(czas == 0){  printf("Koniec czasu!!!\n"); }
        else         {  printf("ZLA ODPOWIEDZ\n");   }
        printf("poprawna odpowiedz to: %c \n \n",(*nowy)->poprawna);
        tabzycia[*aktualnyGracz]--;
    }
    if(tabzycia[*aktualnyGracz]<=0){
        printf("\n gracz %d przegral!!!\n",*aktualnyGracz+1);
        return 0;
    }
}
//----------------------------------------------NIEUKONCZONY!!!--------------------------------------------
void tryb_odwrucony(struct Pytanie *head, struct Pytanie **nowy, char poprawna, int *aktualnyGracz, int *zdobytePunkty, int liczbaGraczy, int *tura, int czas_gry)
{
    int i,j=0,byl=0,ok=0;
    char bylo[3],mozliwe[4]={'a','b','c','d'};
    if(*nowy == NULL){ *nowy = head->nastepny; }
    printf("\n\t---------------Odpowiada gracz nr %d------------\n",*aktualnyGracz+1);
    printf("\n\t-------------MASZ %ds NA ODPOWIEDZ!!!----------\n\n",czas_gry);
    printf("\n\t------------------- q rezygnuje --------------\n\n");
    printf("%d.%s",*tura, (*nowy)->tresc);
    printf("%s", (*nowy)->odpowiedzi);
    do{
    if(byl==1) break;
    //---------ograniczenie czasowe--------------
    srand(time(0));
    int czas=1;
    clock_t start = clock();
    while(czas){

    if(clock()-start>czas_gry*1000) { czas=0; break; }
    if(kbhit())
    {
        scanf(" %c", &poprawna);
        break;
    }
}
    //---------ograniczenie czasowe--------------
    for(i=0;i<3;i++){
        if(bylo[i]==poprawna){
            printf("Ta odpowiedz juz padla -3 pkt");
            zdobytePunkty[*aktualnyGracz] -= 3;
            byl=1;
        }
    }
    if(byl==1 || poprawna=='q') break;
    //---------ograniczenie czasowe--------------
    i=0;
    while(i<4 && ok==0){
        if(mozliwe[i]==poprawna) ok++;
        i++;
    }
    if(ok==1){
    if(poprawna == (*nowy)->poprawna)
    {
        printf("POPRAWNA ODPOWIEDZ! -1pkt\n");
        zdobytePunkty[*aktualnyGracz] -= 1;
        break;
    }
    else
    {
        printf("ZLA ODPOWIEDZ +1pkt\n");
        zdobytePunkty[*aktualnyGracz] += 1;
        bylo[j]=poprawna;
        j++;
    }
    }else{
    printf("odpowiedz z poza zakresu -3 pkt");
    zdobytePunkty[*aktualnyGracz] -= 3;
    byl=1;
    }
    }while(poprawna != (*nowy)->poprawna);
    j=0;
    byl=0;
    for(i=0;i<3;i++) bylo[i]=NULL;
}

void tryb_milionerzy(struct Pytanie *head, struct Pytanie **nowy, char poprawna, int *aktualnyGracz, int *zdobytePunkty, int liczbaGraczy, int *tura,int tabzycia[],int liczbaTur,int koloratunkowe[])
{
    int punkty[MAX]={500,1000,2000,5000,10000,20000,40000,75000,125000,250000,500000,1000000};
    float a,b,c,d,procent,publiczny_traf;//publicznosc
    char blad[4]={'a','b','c','d'};//bledna odpowedz
    int losy,pomylka,prog=*tura-1,decyzja;
    if(*nowy == NULL){ *nowy = head->nastepny; }
    printf("\n\n\t--------------------grasz o: %d zl--------------------\n",punkty[prog]);
    if(koloratunkowe[0]==1) printf("\n1-publicznosc\n");
    if(koloratunkowe[1]==1) printf("2-telefon do przyjaciela\n");
    if(koloratunkowe[2]==1) printf("3-pomin pytanie\n\n");
                            printf("4-rezygnuje\n\n");
    printf("%s", (*nowy)->tresc);
    printf("%s", (*nowy)->odpowiedzi);
    //-----------------------
    srand(time(0));
    losy=rand()%30+1;
    pomylka=rand()%3;
    //-----publicznosc
    a=rand()%10;
    b=rand()%10;
    c=rand()%10;
    d=rand()%10;
    publiczny_traf=rand()%30+1;
    if(((*nowy)->poprawna)=='a') a=publiczny_traf;
    if(((*nowy)->poprawna)=='b') b=publiczny_traf;
    if(((*nowy)->poprawna)=='c') c=publiczny_traf;
    if(((*nowy)->poprawna)=='d') d=publiczny_traf;
    procent=a+b+c+d;
    //---------kola ratunkowe--------------
    scanf("%d",&decyzja);
    if((koloratunkowe[0]==1) && (decyzja==1))
    {//publicznosc
        printf("a) %.2f \n",a/procent);
        printf("b) %.2f \n",b/procent);
        printf("c) %.2f \n",c/procent);
        printf("d) %.2f \n",d/procent);
        koloratunkowe[0]=0;
    }
    if((koloratunkowe[1]==1) && (decyzja==2))
    {//telefon do przyjaciela
        if(losy>10){ printf("Przyjaciel twierdzi ze poprawna odpowiedz to: %c \n \n",(*nowy)->poprawna); }
        else{ printf("Przyjaciel twierdzi ze poprawna odpowiedz to: %c \n \n",blad[pomylka]);}
        koloratunkowe[1]=0;
    }
    if((koloratunkowe[2]==1) && (decyzja==3))
    {
            for(int i=0;i<=losy;i++)
            {
                if((*nowy)->nastepny != NULL){
                    *nowy = (*nowy)->nastepny;
                }else *nowy = head->nastepny;
            }
                printf("%s", (*nowy)->tresc);
                printf("%s", (*nowy)->odpowiedzi);
                koloratunkowe[2]=0;
    }
    if(decyzja==4)
    {//rezygnacja
        printf("poprawna odpowiedz to: %c \n \n",(*nowy)->poprawna);
        tabzycia[*aktualnyGracz]--;
        *tura=liczbaTur;
    }else{
//---------------------GRA  wlasciwa-------------------------------------
            scanf(" %c", &poprawna);
            if(poprawna == (*nowy)->poprawna)
            {
                zdobytePunkty[*aktualnyGracz] = punkty[prog];
                printf("POPRAWNA ODPOWIEDZ \n");
            }
            else
            {
                printf("Koniec gry!\n");
                printf("poprawna odpowiedz to: %c \n \n",(*nowy)->poprawna);
                //tymczasowe
                tabzycia[*aktualnyGracz]--;
                *tura=liczbaTur;
                if(zdobytePunkty[*aktualnyGracz] < 1000){ zdobytePunkty[*aktualnyGracz] = 0;}
                if((zdobytePunkty[*aktualnyGracz] < 40000)  && (zdobytePunkty[*aktualnyGracz] >= 1000)){ zdobytePunkty[*aktualnyGracz] = 1000;}
                if((zdobytePunkty[*aktualnyGracz] < 1000000) && (zdobytePunkty[*aktualnyGracz] >= 40000)){ zdobytePunkty[*aktualnyGracz] = 40000;}
            }
    }
}
