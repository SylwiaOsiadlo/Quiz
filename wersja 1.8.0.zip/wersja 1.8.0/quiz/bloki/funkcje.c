void zmiana_pytania(struct Pytanie *head, struct Pytanie **nowy, int *aktualnyGracz,int liczbaGraczy)
{
    int losy;
    srand(time(0));
    losy=rand()%30+1;
        (*aktualnyGracz)++;
    if(*aktualnyGracz == liczbaGraczy)
        *aktualnyGracz = 0;
    for(int i=0;i<=losy;i++)
    {
    if((*nowy)->nastepny != NULL){
        *nowy = (*nowy)->nastepny;
    }else *nowy = head->nastepny;
    }
}

void trudnosc(int trybgrywybur,int poziomTrudnosci,char wybranakategoria[],char sciezka[],char nazwatrudnosc[],int nazwaKategorii)
{
    strcpy(sciezka,"Pytania/");
    strcpy(wybranakategoria,"brak");
        switch(poziomTrudnosci)
        {
            case 1:
                strncat(sciezka,"latwy/", 6);
                strcpy(nazwatrudnosc,"latwy");
                if(trybgrywybur==3){ printf("za niski poziom trudnosci dla (trybu odwruconego)!!!\n");
                while(poziomTrudnosci<=1 || poziomTrudnosci>=4){
                    scanf("%d",&poziomTrudnosci);
                    strcpy(sciezka,"Pytania/");
                    strcpy(wybranakategoria,"brak");
                    switch(poziomTrudnosci)
                    {
                    case 2:
                        strncat(sciezka,"sredni/", 7);
                        strcpy(nazwatrudnosc,"sredni");
                    break;
                    case 3:
                            strncat(sciezka, "trudny/", 7);
                            strcpy(nazwatrudnosc, "trudny");
                    break;
                        default: printf("nie ma takiej opcji");
                        }}}
            break;
            case 2:
                strncat(sciezka,"sredni/", 7);
                strcpy(nazwatrudnosc,"sredni");
            break;
            case 3:
                strncat(sciezka, "trudny/", 7);
                strcpy(nazwatrudnosc, "trudny");
            break;
            default: printf("nie ma takiej opcji");
    }
    kategorie(nazwaKategorii,sciezka,wybranakategoria);
}

void trybygry(int trybgrywybur,char trybgry[],int poziomTrudnosci,char wybranakategoria[],char sciezka[],char nazwatrudnosc[],int *liczbaTur,int *liczbaGraczy,int *zycia,int tabzycia[])
{
    switch(trybgrywybur)
    {
        case 1:
            strcpy(trybgry, "klasyczny");
        break;
        case 2:
            strcpy(trybgry, "ruletka");
        break;
            case 3:
                strcpy(trybgry, "odwrucony");
                if(poziomTrudnosci==1){
                printf("wymagany 1-sredni lub 2-trudny poziom trudnosci");
                scanf("%d",&poziomTrudnosci);
                strcpy(sciezka,"Pytania/");
                strcpy(wybranakategoria,"brak");
                    switch(poziomTrudnosci)
                    {
                    case 1:
                        strncat(sciezka,"sredni/", 7);
                        strcpy(nazwatrudnosc,"sredni");
                    break;
                    case 2:
                        strncat(sciezka, "trudny/", 7);
                        strcpy(nazwatrudnosc, "trudny");
                    break;
                    default: printf("nie ma takiej opcji");
                    }
                }
            break;
            case 4:
                strcpy(trybgry, "milionerzy");
                *liczbaTur=12;
                *liczbaGraczy=1;
                strcpy(sciezka,"Pytania/trudny/");
                strcpy(nazwatrudnosc, "trudny");
                strcpy(wybranakategoria, "brak");
            break;
            case 5:
                printf("ile ma byc zyc? ");
                scanf("%d",&zycia);
                for(int i=0;i<10;i++){
                    tabzycia[i]=zycia;
                }
                strcpy(trybgry, "survival");
            break;
    }
}

void kategorie(int nazwaKategorii,char sciezka[],char wybranakategoria[])
{

    switch(nazwaKategorii)
    {
        case 1:
            strncat(sciezka,"nauka.txt",9);
            strcpy(wybranakategoria, "nauka");
        break;
        case 2:
            strncat(sciezka,"informatyka.txt",15);
            strcpy(wybranakategoria, "informatyka");
        break;
        case 3:
            strncat(sciezka,"filmy.txt",9);
            strcpy(wybranakategoria, "filmy");
        break;
        case 4:
            strncat(sciezka,"matematyka.txt",14);
            strcpy(wybranakategoria, "matematyka");
        break;
        case 5:
            strncat(sciezka,"historia.txt",12);
            strcpy(wybranakategoria, "historia");
        break;
        case 6:
            strncat(sciezka,"motoryzacja.txt",15);
            strcpy(wybranakategoria, "motoryzacja");
        break;
        case 7:
            strncat(sciezka, "biologia.txt", 12);
            strcpy(wybranakategoria, "biologia");
        break;
        case 8:
            strncat(sciezka,"zwierzeta.txt",13);
            strcpy(wybranakategoria, "zwierzeta");
        break;
        case 9:
            strncat(sciezka,"geografia.txt",13);
            strcpy(wybranakategoria, "geografia");
        break;
        case 10:
            strncat(sciezka, "niestandardowe.txt", 18);
            strcpy(wybranakategoria,"niestandardowe");
        break;
        default: printf("nie ma takiej opcji");
    }
}
