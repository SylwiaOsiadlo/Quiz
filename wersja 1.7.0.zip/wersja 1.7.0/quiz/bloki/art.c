void logo()
{
         printf("wersja: 1.7.0\n");
         printf("              QQQQQQQQ      UUUUUU    UUUUUU     IIIII     ZZZZZZZZZZZZZZZZZZZZZ  !!!  \n");
         printf("            QQQQQQQQQQQQ     UUUU      U UU     II   II    ZZZZZ           ZZZZ   !!!  \n");
         printf("           QQQQQ    QQQQQ    UUUU      U UU     II II I    ZZZ            ZZZZ    !!!  \n");
         printf("           QQQQ      QQQQ    UUUU      U UU     II  II     Z            ZZZZ      !!!  \n");
         printf("           QQQQ      QQQQ    UUUU      U UU      III II               ZZZZ        !!!  \n");
         printf("           QQQQ      QQQQ    UUUU      U UU                         ZZZZ          !!!  \n");
         printf("           QQQQ      QQQQ    UUUU      U UU     IIIIIII           ZZZZ            !!!  \n");
         printf("           QQQQ  QQQ QQQQ    UUUU      U UU      I   I          ZZZZ              !!!  \n");
         printf("           QQQQ   QQQ QQQ    UUUU      U UU      I   I        ZZZZ             Z  !!!  \n");
         printf("           QQQQQ   QQQ QQ     UUUU    U UU       I   I       ZZZZ            ZZZ       \n");
         printf("             QQQQQQ QQQ        UUUUUUU UU       I     I     ZZZZ           ZZZZZ  !!!  \n");
         printf("                QQQQ  QQQ        UUUUUU       IIIIIIIIIII  ZZZZZZZZZZZZZZZZZZZZZ  !!!  \n");

         printf("\n Witaj w naszym super uper QUIZIE!!! (fanfary)\n\n");
         printf("Autorzy:\n  Sebastian Pindral - Deweloper\n  Sylwia Osiadlo    - starszy programista\n  Wiktor Paluch     - mlodszy programista\n");
         printf("\n MENU:\n");
         printf("     1-Nowa gra\n");
         printf("     2-ustawienia\n");
         printf("     3-dodaj pytanie\n");
         printf("     4-Wyjscie\n");
}
