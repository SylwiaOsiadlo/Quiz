#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define ROZ 300
#define MAX 50

#include "bloki/getline.c"
#include "bloki/baza_pytan.c"
#include "bloki/listy.c"
#include "bloki/funkcje.c"
#include "bloki/art.c"

/////////////////////////////////////////////////////////////////////////////////
int main()
{
    char sciezka[ROZ]={"Pytania/sredni/informatyka.txt"},dodawanie[ROZ]={"Pytania/"},tresc[ROZ],odpowiedzi[ROZ],poprawna = -1;
//----------------------------Ustawienia Rozgrywki-------------------------
    int liczbaGraczy=1, aktualnyGracz = 0, liczbaTur=1;
    int *zdobytePunkty,wygrany=0,pktwygranego=0,remis=0,czas_gry=30;
//----------------------------Menu Ustawien--------------------------------
    int poziomTrudnosci = 2, nazwaKategorii = 0,menu,ustawienia,trybgrywybur=1,i;
    char nazwatrudnosc[MAX]="sredni",wybranakategoria[MAX]="informatyka",trybgry[MAX]="klasyczny";
//----------------------------pomoc do trybow------------------------------
    int zycia=1,tabzycia[MAX]={1,1,1,1,1},nn,koloratunkowe[3]={1,1,1};
//----------------------------dodawanie pytan------------------------------
    int dlugosc_pytania = 0;
    struct bazaPytan quiz[MAX];
    FILE *wlasnePytanie;
//----------------------------listy----------------------------------------
    struct Pytanie *head = malloc(sizeof(struct Pytanie));
    poczatek_listy(head);
    struct Pytanie *nowy = NULL;
//----------------------------MENU-----------------------------------------
    while(1)
    {
           logo();//art.c
           scanf("%d",&menu);
        switch(menu)
        {
        case 1:
        {//Nowa gra
//--------------------------------TABLICA PUNKTOW---------------------------------------
                zdobytePunkty = (int*)malloc(liczbaGraczy * sizeof(int));
                for(int i = 0; i < liczbaGraczy; i++)
                    zdobytePunkty[i] = 0;
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX-------CZESC_GLUWNA-------XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    wczytajPytania(head, sciezka, tresc, odpowiedzi, poprawna);
    for(int tura = 1; tura <= liczbaTur; tura++)
    {
     if(trybgrywybur != 4 )   printf("\n\n\t///////////////////// Runda %d\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ \n",tura);
        for(int j = 0; j < liczbaGraczy; j++)
        {
            switch(trybgrywybur){
            case 1:
                tryb_klasyczny(head, &nowy, poprawna, &aktualnyGracz, zdobytePunkty, liczbaGraczy, &tura,czas_gry);
            break;
            case 2:
                tryb_ruletka(head, &nowy, poprawna, &aktualnyGracz, zdobytePunkty, liczbaGraczy, &tura,czas_gry);
            break;
            case 3:
                tryb_odwrucony(head, &nowy, poprawna, &aktualnyGracz, zdobytePunkty, liczbaGraczy, &tura,czas_gry);
            break;
            case 4:
                tryb_milionerzy(head, &nowy, poprawna, &aktualnyGracz, zdobytePunkty, liczbaGraczy, &tura,tabzycia,liczbaTur,koloratunkowe);
            break;
            case 5:
                tryb_survival(head, &nowy, poprawna, &aktualnyGracz, zdobytePunkty, liczbaGraczy, &tura,czas_gry,zycia,tabzycia);
            break;
            }
            nn=j;
            if(tabzycia[j]<=0) break;
        }
         if((tura == liczbaTur) && (trybgrywybur < 5))//warunek survival
         {
             if(trybgrywybur>=4){
                     puts("\n\n Wygrales!\n");
             }else   puts("\n\n Koniec Gry!\n");
            puts("Tabela wynikow:\n");

            for(int j = 0; j < liczbaGraczy; j++)
            {
                printf("Gracz nr %d uzyskal: %d pkt\n", j+1, zdobytePunkty[j]);
                if(pktwygranego<zdobytePunkty[j])
                    {
                        wygrany=j+1;
                        pktwygranego=zdobytePunkty[j];
                    }
            }
                if(liczbaGraczy>1)
                    {
                        i=liczbaGraczy;
                        while(i)
                        {
                            if(zdobytePunkty[i]==pktwygranego) remis++;
                            i--;
                        }
                        if(remis != 0) printf("\n Remis!!!\n\n");
                        else   { printf("Wygral gracz nr %d !!! \n\n",wygrany);}
                    }
        }
        printf("\n");
        if(tabzycia[nn]<=0) break;
    }
  //------------------Ranking--------------------------
     zapisz_rekord(pktwygranego,trybgrywybur);
   system("pause");
        }
    break;
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        case 2:
            do{
            system("cls"); //----------Menu Ustawien--------------
         printf("\n -----------------Ustawienia Rozgrywki------------------------ \n\n");
         printf("   1-wybor ilosci graczy      (Ustawiono= %d )\n",liczbaGraczy);
         printf("   2-wybor ilosci Tur         (Ustawiono= %d )\n",liczbaTur);
         printf("\n -----------------Ustawienia Trudnosci------------------------ \n\n");
         printf("   3-wybor poziomu trudnosci  (Ustawiono= %s )\n",nazwatrudnosc);
         printf("   4-wybor kategori           (Ustawiono= %s )\n",wybranakategoria);
         printf("   5-czas na odpowiedz        (Ustawiono= %ds )\n",czas_gry);
         printf("\n -----------------Ustawienia Trybow Gry------------------------ \n\n");
         printf("   6-tryb gry                 (Ustawiono= %s )\n",trybgry);
         if(trybgrywybur==5){printf("                              (zycia=%d)\n",zycia);}
         printf("\n\n   9-powrot\n");
         scanf("%d",&ustawienia);

            switch(ustawienia)
            {
/*ustawienia*/      case 1://wybor ilosci graczy
                        printf("Podaj liczbe graczy: "); // LICZBA GRACZY
                        scanf("%d", &liczbaGraczy);
                    break;
/*ustawienia*/      case 2://wybor ilosci Tur
                        printf("Podaj liczbe rund: "); // LICZBA RUND
                        scanf("%d", &liczbaTur);
                    break;
/*ustawienia*/      case 4://wybor kategori
                            printf("\nWybierz kategorie:");
                            printf("\n 1-NAUKA\n 2-INFORMATYKA\n 3-FILMY\n 4-MATEMATYKA\n 5-HISTORIA");
                            printf("\n 6-MOTORYZACJA\n 7-BIOLOGIA\n 8-ZWIERZETA\n 9-GEOGRAFIA\n 10-dodane_przez_gracza\n");
                            scanf("%d",&nazwaKategorii);

                            switch(nazwaKategorii){
                                    case 1:
                                        strncat(sciezka,"nauka.txt",9);
                                        strcpy(wybranakategoria, "nauka");
                                    break;
                                    case 2:
                                        strncat(sciezka,"informatyka.txt",15);
                                        strcpy(wybranakategoria, "informatyka");
                                    break;
                                    case 3:
                                        strncat(sciezka,"filmy.txt",9);
                                        strcpy(wybranakategoria, "filmy");
                                    break;
                                    case 4:
                                        strncat(sciezka,"matematyka.txt",14);
                                        strcpy(wybranakategoria, "matematyka");
                                    break;
                                    case 5:
                                        strncat(sciezka,"historia.txt",12);
                                        strcpy(wybranakategoria, "historia");
                                    break;
                                    case 6:
                                        strncat(sciezka,"motoryzacja.txt",15);
                                        strcpy(wybranakategoria, "motoryzacja");
                                    break;
                                    case 7:
                                        strncat(sciezka, "biologia.txt", 12);
                                        strcpy(wybranakategoria, "biologia");
                                    break;
                                    case 8:
                                        strncat(sciezka,"zwierzeta.txt",13);
                                        strcpy(wybranakategoria, "zwierzeta");
                                    break;
                                    case 9:
                                        strncat(sciezka,"geografia.txt",13);
                                        strcpy(wybranakategoria, "geografia");
                                    break;
                                    case 10:
                                        strncat(sciezka, "dodane_przez_gracza.txt", 23);
                                        strcpy(wybranakategoria,"dodane_przez_gracza");
                                    break;
                                    default: printf("nie ma takiej opcji");
                                    }
                    break;
/*ustawienia*/      case 3://wybor poziomu trudnosci
                            printf("\nWybierz poziom trudnosci:\n 1-LATWY P-PRAWDA/F-FALSZ\n 2-SREDNI a) b) c)\n 3-TRUDNY a) b) c) d)\n 4-dodane_przez_gracza\n");
                            scanf("%d",&poziomTrudnosci);
                                strcpy(sciezka,"Pytania/");
                                strcpy(wybranakategoria,"brak");
                            switch(poziomTrudnosci)
                            {
                                case 1:
                                    strncat(sciezka,"latwy/", 6);
                                    strcpy(nazwatrudnosc,"latwy");
                                    if(trybgrywybur==3) printf("za niski poziom trudnosci dla (trybu odwruconego)!!!\n");
                                    while(poziomTrudnosci<=1 || poziomTrudnosci>=4){
                                        scanf("%d",&poziomTrudnosci);
                                        strcpy(sciezka,"Pytania/");
                                        strcpy(wybranakategoria,"brak");
                                        switch(poziomTrudnosci)
                                        {
                                        case 2:
                                            strncat(sciezka,"sredni/", 7);
                                            strcpy(nazwatrudnosc,"sredni");
                                        break;
                                        case 3:
                                            strncat(sciezka, "trudny/", 7);
                                            strcpy(nazwatrudnosc, "trudny");
                                        break;
                                        default: printf("nie ma takiej opcji");
                                        }}
                                break;
                                case 2:
                                    strncat(sciezka,"sredni/", 7);
                                    strcpy(nazwatrudnosc,"sredni");
                                break;
                                case 3:
                                    strncat(sciezka, "trudny/", 7);
                                    strcpy(nazwatrudnosc, "trudny");
                                break;
                                default: printf("nie ma takiej opcji");
                            }
                    break;
/*ustawienia*/      case 5://czas gry
                        printf("podaj ile ma byc sekund na odpowiedz: ");
                        scanf("%d",&czas_gry);
                    break;
/*ustawienia*/      case 6://Tryb gry
                        printf("\n 1-klasyczny\n");
                        printf(" 2-ruletka - mozna zgadac odpowiedz wczesniej za wiecej pkt\n");
                        printf(" 3-odwrucony - punkty za bledne odpowiedzi \n");
                        printf(" 4-milionerzy - po prostu milionerzy ;) xdd \n");
                        printf(" 5-survival - bledna odpowiedz konczy gre \n ");
                        scanf("%d",&trybgrywybur);
                            switch(trybgrywybur)
                            {
                            case 1:
                                    strcpy(trybgry, "klasyczny");
                            break;
                            case 2:
                                    strcpy(trybgry, "ruletka");
                            break;
                            case 3:
                                    strcpy(trybgry, "odwrucony");
                                    if(poziomTrudnosci==1){
                                    printf("wymagany 1-sredni lub 2-trudny poziom trudnosci");
                                    scanf("%d",&poziomTrudnosci);
                                strcpy(sciezka,"Pytania/");
                                strcpy(wybranakategoria,"brak");
                                    switch(poziomTrudnosci)
                                    {
                                    case 1:
                                        strncat(sciezka,"sredni/", 7);
                                        strcpy(nazwatrudnosc,"sredni");
                                    break;
                                    case 2:
                                        strncat(sciezka, "trudny/", 7);
                                        strcpy(nazwatrudnosc, "trudny");
                                    break;
                                    default: printf("nie ma takiej opcji");
                                    }
                                    }
                            break;
                            case 4:
                                    strcpy(trybgry, "milionerzy");
                                    liczbaTur=12;
                                    liczbaGraczy=1;
                                    strcpy(sciezka,"Pytania/trudny/");
                                    strcpy(nazwatrudnosc, "trudny");
                                    strcpy(wybranakategoria, "brak");
                            break;
                            case 5:
                                    printf("ile ma byc zyc? ");
                                    scanf("%d",&zycia);
                                    for(int i=0;i<10;i++){
                                        tabzycia[i]=zycia;
                                    }
                                    strcpy(trybgry, "survival");
                            break;
                            }
                    break;
            }
            }while(ustawienia != 9);
            break;
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        case 3:
        {
            int dodajpoziom=0;
            printf("\nWybierz poziom trudnosci:\n 1-LATWY P-PRAWDA/F-FALSZ\n 2-SREDNI a) b) c)\n 3-TRUDNY a) b) c) d)\n");
            scanf("%d",&dodajpoziom);
            switch(dodajpoziom){
                case 1:
                    strcpy(dodawanie, "Pytania/latwy/dodane_przez_gracza.txt");
                break;
                case 2:
                    strcpy(dodawanie, "Pytania/sredni/dodane_przez_gracza.txt");
                break;
                case 3:
                    strcpy(dodawanie, "Pytania/trudny/dodane_przez_gracza.txt");
                break;
            }
            if ((wlasnePytanie = fopen(dodawanie,"a")) == NULL)
            {
                fputs("Nie mozna otworzyc pliku.\n",stderr);//strumien bledow
                exit(1);
            }
            rewind(wlasnePytanie);
            zapis_do_pliku(wlasnePytanie,dlugosc_pytania,quiz,dodajpoziom);
        }
        break;
        case 4:
            exit(0);
        break;
        default: printf("nie ma takiej opcji");
        }
        system("cls");
        ustawienia=0;
    }
    return 0;
}
