struct bazaPytan
{
    char tresc[MAX];
    char a[MAX];
    char b[MAX];
    char c[MAX];
    char d[MAX];
    char poprawnaOdp[MAX];
};

int zapis_do_pliku(FILE *wlasnePytanie, int dlugosc_pytania, struct bazaPytan quiz[])
{
    puts("Podaj tresc pytania:");
    gets(quiz[dlugosc_pytania].tresc);
    gets(quiz[dlugosc_pytania].tresc);

        printf(" Odp a)");
        gets(quiz[dlugosc_pytania].a);
        printf(" Odp b)");
        gets(quiz[dlugosc_pytania].b);
        printf(" Odp c)");
        gets(quiz[dlugosc_pytania].c);
        printf(" Odp d)");
        gets(quiz[dlugosc_pytania].d);
        printf("Podaj poprawna odpowiedz: ");
        gets(quiz[dlugosc_pytania].poprawnaOdp);

        fprintf(wlasnePytanie, "%s\n",&quiz[dlugosc_pytania].tresc);
        fprintf(wlasnePytanie, "a)%s\n",&quiz[dlugosc_pytania].a);
        fprintf(wlasnePytanie, "b)%s\n",&quiz[dlugosc_pytania].b);
        fprintf(wlasnePytanie, "c)%s\n",&quiz[dlugosc_pytania].c);
        fprintf(wlasnePytanie, "d)%s\n",&quiz[dlugosc_pytania].d);
        fprintf(wlasnePytanie, "%s\n\n",&quiz[dlugosc_pytania].poprawnaOdp);

    return 1;
}
