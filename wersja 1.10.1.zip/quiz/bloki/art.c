void logo()
{
         printf("wersja: 1.10.1\n");
         printf("              QQQQQQQQ      UUUUUU    UUUUUU     QQQQQ     ZZZZZZZZZZZZZZZZZZZZZ  !!!  \n");
         printf("            QQQQQQQQQQQQ     UUUU      U UU     QQ   QQ    ZZZZZ           ZZZZ   !!!  \n");
         printf("           QQQQQ    QQQQQ    UUUU      U UU     QQ QQ Q    ZZZ            ZZZZ    !!!  \n");
         printf("           QQQQ      QQQQ    UUUU      U UU     QQ  QQ     Z            ZZZZ      !!!  \n");
         printf("           QQQQ      QQQQ    UUUU      U UU      QQQ QQ               ZZZZ        !!!  \n");
         printf("           QQQQ      QQQQ    UUUU      U UU                         ZZZZ          !!!  \n");
         printf("           QQQQ      QQQQ    UUUU      U UU     IIIIIII           ZZZZ            !!!  \n");
         printf("           QQQQ  QQQ QQQQ    UUUU      U UU      I   I          ZZZZ              !!!  \n");
         printf("           QQQQ   QQQ QQQ    UUUU      U UU      I   I        ZZZZ             Z  !!!  \n");
         printf("           QQQQQ   QQQ QQ     UUUU    U UU       I   I       ZZZZ            ZZZ       \n");
         printf("             QQQQQQ QQQ        UUUUUUU UU       I     I     ZZZZ           ZZZZZ  !!!  \n");
         printf("                QQQQ  QQQ        UUUUUU       IIIIIIIIIII  ZZZZZZZZZZZZZZZZZZZZZ  !!!  \n");

         printf("\n Witaj w naszym super uper QUIZIE!!! (fanfary)\n\n");
         printf("Autorzy:\n  Sebastian Pindral - starszy programista\n  Sylwia Osiadlo    - programista\n  Wiktor Paluch     - mlodszy programista\n");
         printf("\n MENU:\n");
         printf("     1-Nowa gra\n");
         printf("     2-ustawienia\n");
         printf("     3-dodaj pytanie\n");
         printf("     4-Wyswietl tabele wynikow\n\n");
         printf("     5-Wyjscie\n");
}

void wypisz_tryby_gry()
{
    printf("\n 1-klasyczny\n");
    printf(" 2-ruletka - mozna zgadac odpowiedz wczesniej za wiecej pkt\n");
    printf(" 3-odwrucony - punkty za bledne odpowiedzi \n");
    printf(" 4-zespolowy\n");
    printf(" 5-milionerzy - po prostu milionerzy ;) xdd \n");
    printf(" 6-survival - bledna odpowiedz konczy gre \n ");
}
