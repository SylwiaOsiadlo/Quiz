struct bazaPytan
{
    char tresc[MAX];
    char a[MAX];
    char b[MAX];
    char c[MAX];
    char d[MAX];
    char poprawnaOdp[MAX];
};

int zapis_do_pliku(FILE *wlasnePytanie, int dlugosc_pytania, struct bazaPytan quiz[],int dodajpoziom)
{
    puts("Podaj tresc pytania:");
    gets(quiz[dlugosc_pytania].tresc);
    gets(quiz[dlugosc_pytania].tresc);

        switch(dodajpoziom)
        {
            case 1:
                printf("Podaj poprawna odpowiedz(p/f): ");
                gets(quiz[dlugosc_pytania].poprawnaOdp);
                fprintf(wlasnePytanie, "%s\n",&quiz[dlugosc_pytania].tresc);
                fprintf(wlasnePytanie, "%s\n\n",&quiz[dlugosc_pytania].poprawnaOdp);
            break;
                case 2:
                printf(" Odp a)");
                gets(quiz[dlugosc_pytania].a);
                printf(" Odp b)");
                gets(quiz[dlugosc_pytania].b);
                printf(" Odp c)");
                gets(quiz[dlugosc_pytania].c);
                printf("Podaj poprawna odpowiedz: ");
                gets(quiz[dlugosc_pytania].poprawnaOdp);

                fprintf(wlasnePytanie, "%s\n",&quiz[dlugosc_pytania].tresc);
                fprintf(wlasnePytanie, "a)%s\n",&quiz[dlugosc_pytania].a);
                fprintf(wlasnePytanie, "b)%s\n",&quiz[dlugosc_pytania].b);
                fprintf(wlasnePytanie, "c)%s\n",&quiz[dlugosc_pytania].c);
                fprintf(wlasnePytanie, "%s\n\n",&quiz[dlugosc_pytania].poprawnaOdp);
            break;
            case 3:
                printf(" Odp a)");
                gets(quiz[dlugosc_pytania].a);
                printf(" Odp b)");
                gets(quiz[dlugosc_pytania].b);
                printf(" Odp c)");
                gets(quiz[dlugosc_pytania].c);
                printf(" Odp d)");
                gets(quiz[dlugosc_pytania].d);
                printf("Podaj poprawna odpowiedz: ");
                gets(quiz[dlugosc_pytania].poprawnaOdp);

                fprintf(wlasnePytanie, "%s\n",&quiz[dlugosc_pytania].tresc);
                fprintf(wlasnePytanie, "a)%s\n",&quiz[dlugosc_pytania].a);
                fprintf(wlasnePytanie, "b)%s\n",&quiz[dlugosc_pytania].b);
                fprintf(wlasnePytanie, "c)%s\n",&quiz[dlugosc_pytania].c);
                fprintf(wlasnePytanie, "d)%s\n",&quiz[dlugosc_pytania].d);
                fprintf(wlasnePytanie, "%s\n\n",&quiz[dlugosc_pytania].poprawnaOdp);
            break;
        }
    return 1;
}

void wybiesz_plik(int poziomTrudnosci,char nazwaPliku[],int trybgrywybur)
{
    switch(poziomTrudnosci)
        {
        case 1:
            strncat(nazwaPliku,"latwy/", 6);
        break;
        case 2:
            strncat(nazwaPliku,"sredni/", 7);
        break;
        case 3:
            strncat(nazwaPliku, "trudny/", 7);
        break;
        }
        switch(trybgrywybur)
            {
            case 1:
                    strncat(nazwaPliku, "klasyczny.txt",13);
            break;
            case 2:
                    strncat(nazwaPliku, "ruletka.txt",11);
            break;
            case 3:
                    strncat(nazwaPliku, "odwrucony.txt",13);
            break;
            case 4:
                    strncat(nazwaPliku, "coop.txt",8);
            break;
            case 5:
                    strncat(nazwaPliku, "milionerzy.txt",14);
            break;
            case 6:
                    strncat(nazwaPliku, "survival.txt",12);
            break;
            }
}

void zapisz_rekord(int pktwygranego,int trybgrywybur,int poziomTrudnosci)
{
    char *linia = NULL;
    size_t dlugosc = 0;
    char Poprzedni[MAX];
    int pktPoprzedniego,decyzja,i=1;
    char NICK[MAX];
    char nazwaPliku[MAX]="rekordy/";
        wybiesz_plik(poziomTrudnosci,nazwaPliku,trybgrywybur);
    FILE *plik;
        if ((plik = fopen(nazwaPliku,"a+")) == NULL)
    {
        printf("\nNie mozna otworzyc pliku!\n");
        exit(1);
    }

    printf("-------------------Tabela wynikow-----------------------\n");
    while(getline(&linia, &dlugosc, plik) != -1)
        {
            fscanf(plik,"%s",&Poprzedni);
            fscanf(plik,"%d",&pktPoprzedniego);
            printf("%d.%s %d\n",i,Poprzedni,pktPoprzedniego);
            i++;
        }

    if(pktwygranego>pktPoprzedniego)
    {
        printf("Nowy rekord!\n Czy chcesz zapisac swoj wynik? 1-tak 2-nie: ");
        scanf("%d",&decyzja);
        if(decyzja==1){
        printf("Podaj swoj nick ");
        scanf("%s",&NICK);
        fprintf(plik, "\n%s %d \n",&NICK,pktwygranego);
        }
    }
    fclose(plik);
}

void wyswietl_rekord()
{
    char *linia = NULL;
    size_t dlugosc = 0;
    char Poprzedni[MAX];
    int pktPoprzedniego,i=1,poziomTrudnosci,trybgrywybur;
    char nazwaPliku[MAX]="rekordy/";
        printf("Ktora tabele chcesz zobaczyc?\n");
        printf("\n 1-LATWY P-PRAWDA/F-FALSZ\n 2-SREDNI a) b) c)\n 3-TRUDNY a) b) c) d)\n");
        printf("Wybierz poziom trudnosci: ");
    scanf("%d",&poziomTrudnosci);
        wypisz_tryby_gry();
    printf("Wybierz tryb gry: ");
    scanf("%d",&trybgrywybur);

        wybiesz_plik(poziomTrudnosci,nazwaPliku,trybgrywybur);

    FILE *plik;
        if ((plik = fopen(nazwaPliku,"a+")) == NULL)
    {
        printf("\nNie mozna otworzyc pliku!\n");
        exit(1);
    }

    printf("-------------------Tabela wynikow-----------------------\n");
    while(getline(&linia, &dlugosc, plik) != -1)
        {
            fscanf(plik,"%s",&Poprzedni);
            fscanf(plik,"%d",&pktPoprzedniego);
            printf("%d.%s %d\n",i,Poprzedni,pktPoprzedniego);
            i++;
        }
        system("pause");

    fclose(plik);
}
