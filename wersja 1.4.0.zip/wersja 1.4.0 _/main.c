#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define ROZ 300
#define MAX 50

#include "bloki/getline.c"
#include "bloki/baza_pytan.c"
#include "bloki/listy.c"
#include "bloki/funkcje.c"

void zapisz_rekord(int pktwygranego)
{
    char *linia = NULL;
    size_t dlugosc = 0;
    char Poprzedni[MAX];
    int pktPoprzedniego,decyzja;
    char NICK[MAX];
    char nazwaPliku[MAX]="rekordzista.txt";
    FILE *plik;
        if ((plik = fopen(nazwaPliku,"a+")) == NULL)
    {
        printf("\nNie mozna otworzyc pliku!\n");
        exit(1);
    }

    printf("-------------------Tabela wynikow-----------------------\n");

    fscanf(plik,"%s",&Poprzedni);
    fscanf(plik,"%d",&pktPoprzedniego);

    printf("Poprzedni nalepszy wynik uzyskal: %s , %d punktow \n\n",Poprzedni,pktPoprzedniego);

    if(pktwygranego>pktPoprzedniego)
    {
        printf("Nowy rekord!\n Czy chcesz zapisac swoj wynik? 1-tak 2-nie: ");
        scanf("%d",&decyzja);
        if(decyzja==1){
        printf("Podaj swoj nick ");
        scanf("%s",&NICK);
        fprintf(plik, "\n%s %d",&NICK,&pktwygranego);
        }
    }
    fclose(plik);
}

int main()
{
//-----------------------------GLUWNE--------------------------------------
    char sciezka[ROZ]={"Pytania/latwy/biologia.txt"},dodawanie[ROZ]={"Pytania/"},tresc[ROZ],odpowiedzi[ROZ],poprawna = -1;
//----------------------------Ustawienia Rozgrywki-------------------------
    int liczbaGraczy=1, aktualnyGracz = 0, liczbaTur=1;
    int *zdobytePunkty,wygrany=0,pktwygranego=0,remis=0,czas_gry=10;
//----------------------------Menu Ustawien--------------------------------
    int poziomTrudnosci = 0, nazwaKategorii = 0,menu,ustawienia,trybgrywybur=1;
    char nazwatrudnosc[MAX]="latwy",wybranakategoria[MAX]="biologia",trybgry[MAX]="klasyczny";
//----------------------------dodawanie pytan------------------------------
    int dlugosc_pytania = 0,zycia=1,tabzycia[MAX];
    struct bazaPytan quiz[MAX];
    FILE *wlasnePytanie;
//----------------------------listy----------------------------------------
    struct Pytanie *head = malloc(sizeof(struct Pytanie));
    poczatek_listy(head);
    struct Pytanie *nowy = NULL;
//----------------------------MENU-----------------------------------------
    while(1)
    {
            {//-------------Logo i menu-----------------
         printf("              QQQQQQQQ      UUUUUU    UUUUUU     IIIII     ZZZZZZZZZZZZZZZZZZZZZ  !!!  \n");
         printf("            QQQQQQQQQQQQ     UUUU      U UU     II   II    ZZZZZ           ZZZZ   !!!  \n");
         printf("           QQQQQ    QQQQQ    UUUU      U UU     II II I    ZZZ            ZZZZ    !!!  \n");
         printf("           QQQQ      QQQQ    UUUU      U UU     II  II     Z            ZZZZ      !!!  \n");
         printf("           QQQQ      QQQQ    UUUU      U UU      III II               ZZZZ        !!!  \n");
         printf("           QQQQ      QQQQ    UUUU      U UU                         ZZZZ          !!!  \n");
         printf("           QQQQ      QQQQ    UUUU      U UU     IIIIIII           ZZZZ            !!!  \n");
         printf("           QQQQ  QQQ QQQQ    UUUU      U UU      I   I          ZZZZ              !!!  \n");
         printf("           QQQQ   QQQ QQQ    UUUU      U UU      I   I        ZZZZ             Z  !!!  \n");
         printf("           QQQQQ   QQQ QQ     UUUU    U UU       I   I       ZZZZ            ZZZ       \n");
         printf("             QQQQQQ QQQ        UUUUUUU UU       I     I     ZZZZ           ZZZZZ  !!!  \n");
         printf("                QQQQ  QQQ        UUUUUU       IIIIIIIIIII  ZZZZZZZZZZZZZZZZZZZZZ  !!!  \n");

         printf("\n Witaj w naszym super uper duper QUIZIE!!! (fanfary)\n\n");
         printf("Autorzy:\n  Sebastian Pindral - Deweloper\n  Sylwia Osiadlo    - starszy programista\n  Wiktor Paluch     - mlodszy programista\n");
         printf("\n MENU:\n");
           printf("     1-Nowa gra\n");
           printf("     2-ustawienia\n");
           printf("     3-dodaj pytanie\n");
           printf("     4-Wyjscie\n");
         scanf("%d",&menu);
            }
        switch(menu)
        {
        case 1:
        {//Nowa gra
//--------------------------------TABLICA PUNKTOW---------------------------------------
                zdobytePunkty = (int*)malloc(liczbaGraczy * sizeof(int));
                for(int i = 0; i < liczbaGraczy; i++)
                    zdobytePunkty[i] = 0;

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX-------CZESC_GLUWNA-------XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    wczytajPytania(head, sciezka, tresc, odpowiedzi, poprawna);
    for(int tura = 1; tura <= liczbaTur; tura++)
    {
        printf("\n\n\t--------------------Runda %d--------------------\n",tura);
        for(int j = 0; j < liczbaGraczy; j++)
        {
            switch(trybgrywybur){
            case 1:
                tryb_klasyczny(head, &nowy, poprawna, &aktualnyGracz, zdobytePunkty, liczbaGraczy, &tura,czas_gry);
            break;
            case 2:
                tryb_ruletka(head, &nowy, poprawna, &aktualnyGracz, zdobytePunkty, liczbaGraczy, &tura,czas_gry);
            break;
            case 3:
                tryb_survival(head, &nowy, poprawna, &aktualnyGracz, zdobytePunkty, liczbaGraczy, &tura,czas_gry,zycia,tabzycia);
            break;
            }
        }
         if((tura == liczbaTur) && (trybgrywybur < 3))
         {
            puts("\n\nKoniec Gry!\n");
            puts("Tabela wynikow:\n");

            for(int j = 0; j < liczbaGraczy; j++)
            {
                printf("Gracz nr %d uzyskal: %d pkt\n", j+1, zdobytePunkty[j]);
                if(pktwygranego<zdobytePunkty[j])
                    {
                        wygrany=j+1;
                        pktwygranego=zdobytePunkty[j];
                    }
            }
        }
        printf("\n");
    }
  //------------------Ranking--------------------------
    if((liczbaGraczy>1) && (trybgrywybur < 3))
    {
    int i=liczbaGraczy;
    while(i)
    {
        if(zdobytePunkty[i]==pktwygranego) remis++;
        i--;
    }
    if(remis != 0) printf("Remis!!!\n\n");
    else   { printf("Wygral gracz nr %d !!! \n\n",wygrany);}
    }
//-----------rekordowy wynik-----------------
   // zapisz_rekord(pktwygranego);
//-------------------------------------------
   system("pause");
        }
    break;
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        case 2:
            do{
                    {//----------Menu Ustawien--------------
            system("cls");
         printf("\n -----------------Ustawienia Rozgrywki------------------------ \n\n");
         printf("   1-wybor ilosci graczy      (Ustawiono= %d )\n",liczbaGraczy);
         printf("   2-wybor ilosci Tur         (Ustawiono= %d )\n",liczbaTur);
         printf("   3-wybor kategori           (Ustawiono= %s )\n",wybranakategoria);
         printf("\n -----------------Ustawienia Trudnosci------------------------ \n\n");
         printf("   4-wybor poziomu trudnosci  (Ustawiono= %s )\n",nazwatrudnosc);
         printf("   5-czas na odpowiedz        (Ustawiono= %ds )\n",czas_gry);
         printf("\n -----------------Ustawienia Trybow Gry------------------------ \n\n");
         printf("   6-tryb gry                 (Ustawiono= %s ,zycia=%d)\n",trybgry,zycia);
         printf("\n\n   9-powrot\n   ");
         scanf("%d",&ustawienia);
                    }
            switch(ustawienia)
            {
/*ustawienia*/      case 1://wybor ilosci graczy
                        printf("Podaj liczbe graczy: "); // LICZBA GRACZY
                        scanf("%d", &liczbaGraczy);
                    break;
/*ustawienia*/      case 2://wybor ilosci Tur
                        printf("Podaj liczbe rund: "); // LICZBA RUND
                        scanf("%d", &liczbaTur);
                    break;

/*ustawienia*/      case 3://wybor kategori

                            printf("\nWybierz kategorie:");
                            printf("\n 1-BIOLOGIA\n 2-MATEMATYKA\n 3-ZWIERZETA\n 4-INFORMATYKA\n 5-HISTORIA");
                            printf("\n 6-JEZYK POLSKI\n 7-MOTORYZACJA\n 8-NAUKA\n 9-FILMY\n 10-GEOGRAFIA\n");
                            scanf("%d",&nazwaKategorii);

                            switch(nazwaKategorii){
                                    case 1:
                                        strncat(sciezka, "biologia.txt", 12);// strcpy(sciezka, "Pytania/latwy/biologia.txt");
                                        strcpy(wybranakategoria, "biologia");
                                    break;
                                    case 2:
                                        strncat(sciezka,"matematyka.txt",14);
                                        strcpy(wybranakategoria, "biologia");
                                    break;
                                    case 3:
                                        strncat(sciezka,"zwierzeta.txt",13);
                                        strcpy(wybranakategoria, "matematyka");
                                    break;
                                    case 4:
                                        strncat(sciezka,"informatyka.txt",15);
                                        strcpy(wybranakategoria, "informatyka");
                                    break;
                                    case 5:
                                        strncat(sciezka,"historia.txt",12);
                                        strcpy(wybranakategoria, "historia");
                                    break;
                                    case 6:
                                        strncat(sciezka,"polski.txt",10);
                                        strcpy(wybranakategoria, "polski");
                                    break;
                                    case 7:
                                        strncat(sciezka,"motoryzacja.txt",15);
                                        strcpy(wybranakategoria, "motoryzacja");
                                    break;
                                    case 8:
                                        strncat(sciezka,"nauka.txt",9);
                                        strcpy(wybranakategoria, "nauka");
                                    break;
                                    case 9:
                                        strncat(sciezka,"filmy.txt",9);
                                        strcpy(wybranakategoria, "filmy");
                                    break;
                                    case 10:
                                        strncat(sciezka,"geografia.txt",13);
                                        strcpy(wybranakategoria, "geografia");
                                    break;
                                    default: printf("nie ma takiej opcji");
                                    }
                    break;
/*ustawienia*/      case 4://wybor poziomu trudnosci
                            printf("\nWybierz poziom trudnosci:\n 1-LATWY \n 2-SREDNI \n 3-TRUDNY \n 4-dodane_przez_gracza \n");
                            scanf("%d",&poziomTrudnosci);
                                strcpy(sciezka,"Pytania/");
                                strcpy(wybranakategoria,"brak");
                            switch(poziomTrudnosci)
                            {
                                case 1:
                                    strncat(sciezka,"latwy/", 6);
                                    strcpy(nazwatrudnosc,"latwy");
                                break;
                                case 2:
                                    strncat(sciezka,"sredni/", 7);
                                    strcpy(nazwatrudnosc,"sredni");
                                break;
                                case 3:
                                    strncat(sciezka, "trudny/", 7);
                                    strcpy(nazwatrudnosc, "trudny");
                                break;
                                    case 4:
                                    strncat(sciezka, "dodane_przez_gracza.txt", 23);
                                    strcpy(nazwatrudnosc, "dodane_przez_gracza");
                                    strcpy(nazwaKategorii,"dodane_przez_gracza");
                                break;
                                default: printf("nie ma takiej opcji");
                            }
                    break;
/*ustawienia*/      case 5://czas gry
                        printf("podaj ile ma byc sekund na odpowiedz: ");
                        scanf("%d",&czas_gry);
                    break;
/*ustawienia*/      case 6://Tryb gry
                        printf("\n 1-klasyczny \n 2-ruletka \n 3-survival \n ");
                        scanf("%d",&trybgrywybur);
                            switch(trybgrywybur)
                            {
                            case 1:
                                    strcpy(trybgry, "klasyczny");
                            break;
                            case 2:
                                    strcpy(trybgry, "ruletka");
                            break;
                            case 3:
                                    printf("ile ma byc zyc?");
                                    scanf("%d",&zycia);
                                    for(int i=0;i<10;i++){
                                        tabzycia[i]=zycia;
                                    }
                                    strcpy(trybgry, "survival");
                            break;
                            }
                    break;
            }
            }while(ustawienia != 9);
            break;
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        case 3:
        {
            strncat(dodawanie, "dodane_przez_gracza.txt", 23);
            if ((wlasnePytanie = fopen(dodawanie,"a")) == NULL)
            {
                fputs("Nie mozna otworzyc pliku.\n",stderr);//strumien bledow
                exit(1);
            }
            rewind(wlasnePytanie);
            zapis_do_pliku(wlasnePytanie,dlugosc_pytania,quiz);
        }
        break;
        case 4:
            exit(0);
        break;
        default: printf("nie ma takiej opcji");
        }
        system("cls");
        ustawienia=0;
    }
    return 0;
}
//Wersja gry 1.4.0
