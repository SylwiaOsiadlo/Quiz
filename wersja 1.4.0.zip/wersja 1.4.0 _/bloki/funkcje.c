void tryb_klasyczny(struct Pytanie *head, struct Pytanie **nowy, char poprawna, int *aktualnyGracz, int *zdobytePunkty, int liczbaGraczy, int *tura, int czas_gry)
{
    int losy;
    if(*nowy == NULL){ *nowy = head->nastepny; }

    printf("\n~Odpowiada gracz nr %d~\n", *aktualnyGracz+1);
    printf("\n MASZ %ds NA ODPOWIEDZ!!!\n\n",czas_gry);
    printf("%s", (*nowy)->tresc);
    printf("%s", (*nowy)->odpowiedzi);
    //---------ograniczenie czasowe--------------
    srand(time(0));
    losy=rand()%30+1;
    int czas=1;
    clock_t start = clock();
    while(czas){

    if(clock()-start>czas_gry*1000) { czas=0; break; }
    if(kbhit())
    {
        scanf(" %c", &poprawna);
        break;
    }
}
    //---------ograniczenie czasowe--------------
    if(poprawna == (*nowy)->poprawna)
    {
        zdobytePunkty[*aktualnyGracz] += 1;
        printf("POPRAWNA ODPOWIEDZ \n");
    }
    else
    {
        if(czas == 0){  printf("Koniec czasu!!!\n"); }
        else         {  printf("ZLA ODPOWIEDZ\n");   }
        printf("poprawna odpowiedz to: %c \n \n",(*nowy)->poprawna);
    }
    (*aktualnyGracz)++;
    if(*aktualnyGracz == liczbaGraczy)
        *aktualnyGracz = 0;
    for(int i=0;i<=losy;i++)
    {
    if((*nowy)->nastepny != NULL){
        *nowy = (*nowy)->nastepny;
    }else *nowy = head->nastepny;
    }
}

void tryb_ruletka(struct Pytanie *head, struct Pytanie **nowy, char poprawna, int *aktualnyGracz, int *zdobytePunkty, int liczbaGraczy, int *tura, int czas_gry)
{
    int losy,ruletka=0;
    if(*nowy == NULL){ *nowy = head->nastepny; }

    printf("\n~Odpowiada gracz nr %d~\n", *aktualnyGracz+1);
    printf("\n MASZ %ds NA ODPOWIEDZ!!!\n\n",czas_gry);
    printf("\n 1-Chcesz poznac pytanie?-1pkt czy 2-ryzykujesz?-3pkt \n\n");
    scanf("%d",&ruletka);
    if(ruletka==1){ printf("%s", (*nowy)->tresc); }
    printf("%s", (*nowy)->odpowiedzi);
    //---------ograniczenie czasowe--------------
    srand(time(0));
    losy=rand()%30+1;
    int czas=1;
    clock_t start = clock();
    while(czas){

    if(clock()-start>czas_gry*1000) { czas=0; break; }
    if(kbhit())
    {
        scanf(" %c", &poprawna);
        break;
    }
}
    //---------ograniczenie czasowe--------------
    if(poprawna == (*nowy)->poprawna)
    {
        if(ruletka==2)
        {
            zdobytePunkty[*aktualnyGracz] += 3;
        }else{
        zdobytePunkty[*aktualnyGracz] += 1;
        }
        printf("POPRAWNA ODPOWIEDZ \n");
    }
    else
    {
        if(czas == 0){  printf("Koniec czasu!!!\n"); }
        else         {  printf("ZLA ODPOWIEDZ\n");   }
        printf("poprawna odpowiedz to: %c \n \n",(*nowy)->poprawna);
    }
    (*aktualnyGracz)++;
    if(*aktualnyGracz == liczbaGraczy)
        *aktualnyGracz = 0;
    for(int i=0;i<=losy;i++)
    {
    if((*nowy)->nastepny != NULL){
        *nowy = (*nowy)->nastepny;
    }else *nowy = head->nastepny;
    }
}

void tryb_survival(struct Pytanie *head, struct Pytanie **nowy, char poprawna, int *aktualnyGracz, int *zdobytePunkty, int liczbaGraczy, int *tura, int czas_gry,int zycia,int tabzycia[])
{
    int losy;
    if(*nowy == NULL){ *nowy = head->nastepny; }

    printf("\n~Odpowiada gracz nr %d~\n", *aktualnyGracz+1);
    printf("\n MASZ %ds NA ODPOWIEDZ!!!\n\n",czas_gry);
    printf("\n MASZ %d Zycia!!!\n\n",tabzycia[*aktualnyGracz]);
    printf("%s", (*nowy)->tresc);
    printf("%s", (*nowy)->odpowiedzi);
    //---------ograniczenie czasowe--------------
    srand(time(0));
    losy=rand()%30+1;
    int czas=1;
    clock_t start = clock();
    while(czas){

    if(clock()-start>czas_gry*1000) { czas=0; break; }
    if(kbhit())
    {
        scanf(" %c", &poprawna);
        break;
    }
}
    //---------ograniczenie czasowe--------------
    if(poprawna == (*nowy)->poprawna)
    {
        zdobytePunkty[*aktualnyGracz] += 1;
        printf("POPRAWNA ODPOWIEDZ \n");
    }
    else
    {
        if(czas == 0){  printf("Koniec czasu!!!\n"); }
        else         {  printf("ZLA ODPOWIEDZ\n");   }
        printf("poprawna odpowiedz to: %c \n \n",(*nowy)->poprawna);
        tabzycia[*aktualnyGracz]--;
    }
    if(tabzycia[*aktualnyGracz]==0){
        printf("gracz %d przegral!!!",*aktualnyGracz+1);
        return 1;
    }
    (*aktualnyGracz)++;
    if(*aktualnyGracz == liczbaGraczy)
        *aktualnyGracz = 0;
    for(int i=0;i<=losy;i++)
    {
    if((*nowy)->nastepny != NULL){
        *nowy = (*nowy)->nastepny;
    }else *nowy = head->nastepny;
    }
}
