struct Pytanie//nowy
{
    struct Pytanie *poprzedni;
    struct Pytanie *nastepny;
    char tresc[ROZ];
    char odpowiedzi[ROZ];
    char poprawna;
};
//--------------dlugosc_pytania------------------
struct Pytanie* ostatni_element(struct Pytanie *head)
{
    struct Pytanie *ostatni = head;
    while(ostatni->nastepny != NULL)
    {
        ostatni = ostatni->nastepny;
    }
    return ostatni;
}

void poczatek_listy(struct Pytanie *head)
{
    head->poprzedni = NULL;
    head->nastepny = NULL;
    head->tresc[0] = ' ';
    head->odpowiedzi[0] = ' ';
    head->poprawna = 0;
}
void dodajNaKoniecListy(struct Pytanie *head, char tresc[], char odpowiedzi[], char poprawna)
{
    struct Pytanie *ostatni = ostatni_element(head);
    struct Pytanie *nowePytanie = malloc(sizeof(struct Pytanie));
//uzupelnianie pytania
    nowePytanie->poprzedni = ostatni;
    nowePytanie->nastepny = NULL;
    strcpy(nowePytanie->tresc, tresc); //zapisywanie aktualnego pytania
    strcpy(nowePytanie->odpowiedzi, odpowiedzi);
    nowePytanie->poprawna = poprawna;
    ostatni->nastepny = nowePytanie;
}
void wczytajPytania(struct Pytanie *head, char nazwaPliku[], char tresc[], char odpowiedzi[], char poprawna)
{
    char *linia = NULL;
    size_t dlugosc = 0;
    FILE *plik;
    if ((plik = fopen(nazwaPliku,"r")) == NULL)
    {
        printf("\nNie mozna otworzyc pliku!\n");
        exit(1);
    }
    while(getline(&linia, &dlugosc, plik) != -1)
    {  //Petla zczytuje tresc pytania
        odpowiedzi[0] = '\0';
        strcpy(tresc,linia);

        while(getline(&linia, &dlugosc, plik) != -1)
        {
            if(linia[2] == '\0')
            { //odpowiedz poprawna
                poprawna = linia[0];
                break;
            }
            else
            {   //mozliwe odpowiedzi
                strncat(odpowiedzi,linia,dlugosc);
            }
        }

        dodajNaKoniecListy(head, tresc, odpowiedzi, poprawna);
    }
    fclose(plik);
}
